MONEY MIND native Android project

This build does NOT use appassets.androidplatform.net/web/index.html.
The app loads its bundled UI directly from file:///android_asset/index.html.

Cloud build:
1. Upload this project to a GitHub repository.
2. Open Actions -> Build MONEY MIND APK -> Run workflow.
3. Open the completed run and download the MONEY-MIND-APK artifact.
